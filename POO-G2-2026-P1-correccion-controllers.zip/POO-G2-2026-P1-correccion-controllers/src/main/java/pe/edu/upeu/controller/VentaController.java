package pe.edu.upeu.controller;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import pe.edu.upeu.components.comprob.ComprobantePdfService;
import pe.edu.upeu.components.comprob.ComprobanteView;
import pe.edu.upeu.dto.SessionManager;
import pe.edu.upeu.dto.comprobante.Comprobante;
import pe.edu.upeu.dto.comprobante.ItemComprobante;
import pe.edu.upeu.model.Cliente;
import pe.edu.upeu.model.Usuario;
import pe.edu.upeu.model.Venta;
import pe.edu.upeu.model.VentaDetalle;
import pe.edu.upeu.repository.VentaDetalleRepository;
import pe.edu.upeu.service.IClienteService;
import pe.edu.upeu.service.IUsuarioService;
import pe.edu.upeu.service.IVentaService;

import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class VentaController {

    @FXML private TableView<Venta> tblVenta;
    @FXML private TableColumn<Venta, String> colIdVenta;
    @FXML private TableColumn<Venta, String> colCliente;
    @FXML private TableColumn<Venta, LocalDate> colFecha;
    @FXML private TableColumn<Venta, Double> colNetoTotal;
    @FXML private TableColumn<Venta, Double> colIgv;
    @FXML private TableColumn<Venta, Double> colPrecioTotal;

    @FXML private TextField txtIdVenta;
    @FXML private DatePicker dpFechaVenta;
    @FXML private ComboBox<Cliente> cmbCliente;
    @FXML private TextField txtNetoTotal;
    @FXML private TextField txtIgv;
    @FXML private TextField txtPrecioTotal;

    private final IVentaService ventaService;
    private final IClienteService clienteService;
    private final IUsuarioService usuarioService;
    private final VentaDetalleRepository ventaDetalleRepository = new VentaDetalleRepository();
    private ObservableList<Venta> lista = FXCollections.observableArrayList();

    public VentaController(IVentaService ventaService,
                           IClienteService clienteService,
                           IUsuarioService usuarioService) {
        this.ventaService = ventaService;
        this.clienteService = clienteService;
        this.usuarioService = usuarioService;
    }

    @FXML
    public void initialize() {
        colIdVenta.setCellValueFactory(new PropertyValueFactory<>("idVenta"));
        colFecha.setCellValueFactory(new PropertyValueFactory<>("fechaVenta"));
        colNetoTotal.setCellValueFactory(new PropertyValueFactory<>("netoTotal"));
        colIgv.setCellValueFactory(new PropertyValueFactory<>("igv"));
        colPrecioTotal.setCellValueFactory(new PropertyValueFactory<>("precioTotal"));

        // Mostrar nombre del cliente en la tabla
        colCliente.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDniCliente().getNombre()));

        // Configurar ComboBox de Cliente
        cmbCliente.setCellFactory(lv -> new ListCell<>() {
            @Override
            protected void updateItem(Cliente item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getDni() + " - " + item.getNombre());
            }
        });
        cmbCliente.setButtonCell(new ListCell<>() {
            @Override
            protected void updateItem(Cliente item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getDni() + " - " + item.getNombre());
            }
        });

        // Calcular IGV y Total automáticamente
        txtNetoTotal.textProperty().addListener((obs, old, val) -> calcularTotales(val));

        cargarDatos();

        // Rellenar formulario al seleccionar tabla
        tblVenta.getSelectionModel().selectedItemProperty().addListener((obs, old, sel) -> {
            if (sel != null) {
                txtIdVenta.setText(sel.getIdVenta());
                dpFechaVenta.setValue(sel.getFechaVenta());
                txtNetoTotal.setText(String.valueOf(sel.getNetoTotal()));
                txtIgv.setText(String.valueOf(sel.getIgv()));
                txtPrecioTotal.setText(String.valueOf(sel.getPrecioTotal()));

                cmbCliente.getItems().stream()
                        .filter(c -> c.getDni().equals(sel.getDniCliente().getDni()))
                        .findFirst()
                        .ifPresent(cmbCliente::setValue);
            }
        });
    }

    private void calcularTotales(String netoStr) {
        try {
            double neto = Double.parseDouble(netoStr);

            // Calcula el IGV solo para mostrarlo
            double igv = neto * 0.18;

            txtIgv.setText(String.format(java.util.Locale.US, "%.2f", igv));

            // El precio total permanece igual al neto
            txtPrecioTotal.setText(String.format(java.util.Locale.US, "%.2f", neto));

        } catch (NumberFormatException ignored) {
            txtIgv.clear();
            txtPrecioTotal.clear();
        }
    }

    private void cargarDatos() {
        cmbCliente.setItems(FXCollections.observableArrayList(clienteService.findAll()));
        lista.setAll(ventaService.findAll());
        tblVenta.setItems(lista);
        tblVenta.refresh();
    }

    @FXML
    private void guardar() {
        if (txtIdVenta.getText().isEmpty() || cmbCliente.getValue() == null || dpFechaVenta.getValue() == null) {
            mostrarAlerta("Error", "ID, Cliente y Fecha son obligatorios.");
            return;
        }
        // Validar que el ID no sea negativo
        try {
            int id = Integer.parseInt(txtIdVenta.getText());

            if (id <= 0) {
                mostrarAlerta("Error", "El ID de Venta debe ser un número mayor que 0.");
                return;
            }

        } catch (NumberFormatException e) {
            mostrarAlerta("Error", "El ID de Venta debe ser un número válido.");
            return;
        }
        try {
            // CORRECCIÓN APLICADA: Se usa loginUsuario en lugar de findByUsuarioAndClave
            Usuario usuarioResponsable;
            Optional<Usuario> optUsu = usuarioService.loginUsuario("juan123", "juan123456");

            if(optUsu.isPresent()){
                usuarioResponsable = optUsu.get();
            } else {
                usuarioResponsable = new Usuario();
                usuarioResponsable.setIdUsuario("1");
            }

            Venta v = Venta.builder()
                    .idVenta(txtIdVenta.getText())
                    .dniCliente(cmbCliente.getValue())
                    .fechaVenta(dpFechaVenta.getValue())
                    .netoTotal(Double.parseDouble(txtNetoTotal.getText()))
                    .igv(Double.parseDouble(txtIgv.getText()))
                    .precioTotal(Double.parseDouble(txtPrecioTotal.getText()))
                    .idUsuario(usuarioResponsable)
                    .build();

            if (ventaService.existsById(v.getIdVenta())) {
                ventaService.update(v.getIdVenta(), v);
            } else {
                ventaService.save(v);
            }
            limpiar();
            cargarDatos();
        } catch (NumberFormatException e) {
            mostrarAlerta("Error", "Los montos deben ser numéricos.");
        }
    }

    @FXML
    private void eliminar() {
        Venta sel = tblVenta.getSelectionModel().getSelectedItem();
        if (sel == null) {
            mostrarAlerta("Error", "Seleccione una venta.");
            return;
        }
        ventaService.delete(sel.getIdVenta());
        limpiar();
        cargarDatos();
    }

    @FXML
    private void limpiar() {
        txtIdVenta.clear();
        dpFechaVenta.setValue(null);
        cmbCliente.setValue(null);
        txtNetoTotal.clear();
        txtIgv.clear();
        txtPrecioTotal.clear();
        tblVenta.getSelectionModel().clearSelection();
    }

    @FXML
    private void generarBoleta() {
        Venta sel = tblVenta.getSelectionModel().getSelectedItem();
        if (sel == null) {
            mostrarAlerta("Error", "Seleccione una venta para generar la boleta.");
            return;
        }
        try {
            Comprobante comprobante = construirComprobante(sel);
            mostrarVistaPrevia(comprobante);
        } catch (Exception e) {
            mostrarAlerta("Error", "No se pudo generar la boleta: " + e.getMessage());
        }
    }

    private Comprobante construirComprobante(Venta v) {
        List<VentaDetalle> detalles = ventaDetalleRepository.findByIdVenta(v.getIdVenta());

        List<ItemComprobante> items = detalles.stream()
                .map(d -> ItemComprobante.builder()
                        .cantidad(d.getCantidad())
                        .descripcion(d.getIdProducto().getNombre())
                        .precioUnitario(d.getPrecioUni())
                        .subtotal(d.getNetoTotal())
                        .build())
                .collect(Collectors.toList());

        Cliente cliente = v.getDniCliente();

        return Comprobante.builder()
                .razonSocial("SysVentas Polos E.I.R.L.")
                .rucEmisor("20123456789")
                .direccion("Av. Ejemplo 123")
                .ubigeo("Puno - Puno - Puno")
                .telefono("051-123456")
                .tipoDocumento("BOLETA DE VENTA ELECTRÓNICA")
                .serie("B001")
                .numero(v.getIdVenta())
                .fechaEmision(v.getFechaVenta().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")))
                .moneda("PEN")
                .tipoDocCliente("DNI")
                .nroDocCliente(cliente.getDni())
                .nombreCliente(cliente.getNombre())
                .direccionCliente(cliente.getDireccion())
                .items(items)
                .opGravadas(v.getNetoTotal())
                .igv(v.getIgv())
                .total(v.getPrecioTotal())
                .build();
    }

    private void mostrarVistaPrevia(Comprobante comprobante) {
        ComprobanteView view = new ComprobanteView(comprobante);
        ScrollPane scroll = new ScrollPane(view.construir());
        scroll.setFitToWidth(true);

        Button btnExportar = new Button("  Exportar PDF");
        btnExportar.setStyle("-fx-background-color:#1a4a8a; -fx-text-fill:white; -fx-font-weight:bold; " +
                "-fx-padding:8 16 8 16; -fx-background-radius:6; -fx-cursor:hand;");
        btnExportar.setOnAction(e -> exportarPdf(comprobante));

        HBox barra = new HBox(btnExportar);
        barra.setPadding(new Insets(10));
        barra.setStyle("-fx-background-color:#1e2536;");
        barra.setAlignment(Pos.CENTER_RIGHT);

        BorderPane root = new BorderPane();
        root.setTop(barra);
        root.setCenter(scroll);

        Stage stage = new Stage();
        stage.setTitle("Vista previa - Boleta " + comprobante.getNumero());
        stage.setScene(new Scene(root, 800, 650));
        stage.show();
    }

    private void exportarPdf(Comprobante comprobante) {
        FileChooser chooser = new FileChooser();
        chooser.setInitialFileName("Boleta_" + comprobante.getNumero() + ".pdf");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF", "*.pdf"));
        File file = chooser.showSaveDialog(null);
        if (file == null) return;

        try {
            new ComprobantePdfService().exportar(comprobante, file.toPath());
            mostrarAlerta("Éxito", "PDF generado correctamente.");
        } catch (Exception e) {
            mostrarAlerta("Error", "No se pudo exportar el PDF: " + e.getMessage());
        }
    }

    private void mostrarAlerta(String titulo, String msg) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(titulo);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
