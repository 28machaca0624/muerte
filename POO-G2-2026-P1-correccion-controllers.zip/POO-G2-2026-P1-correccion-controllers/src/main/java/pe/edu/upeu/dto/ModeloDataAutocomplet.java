package pe.edu.upeu.dto;

import lombok.Data;


@Data
public class ModeloDataAutocomplet {
    private String idx;
    private String nameDysplay;
    private String otherData;
    @Override
    public String toString()
    {
        return idx+" - "+nameDysplay;
    }
}
