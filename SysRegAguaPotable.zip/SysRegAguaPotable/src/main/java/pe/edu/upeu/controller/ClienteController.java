package pe.edu.upeu.controller;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import pe.edu.upeu.model.Cliente;
import pe.edu.upeu.service.ClienteService;
import pe.edu.upeu.service.ClienteServiceImp;

public class ClienteController {
    @FXML
    Button btnGuardar, btnActualizar, btnLimpiar, btnEliminar;
    @FXML
    TextField txtDireccion, txtNombre,  txtBuscar;
    @FXML
    ComboBox<String>cboCapacidad;
    @FXML
    ComboBox<String>cboEstado;
    @FXML
    TableView<Cliente> regClienteTabla;
    private TableColumn<Cliente, String> colDireccion, colNombre, colCapacidad, colEstado;
    ObservableList<Cliente> clientes;
    int index=-1;


    ClienteService cs=ClienteServiceImp.getInstance();


    @FXML
    public void initialize(){

        cboCapacidad.getItems().addAll("todo el dia","poca camtidad","sin agua");
        cboEstado.getItems().addAll("NORMAL", "URGENTE", "ALERTA");

        definirColumnas();
        listar();
        agregarEventoSeleccion();
        desacActBotton(true);
        btnEliminar.setOnAction(e->{
            if(index!=-1){
                cs.delete(index);
                listar();
                limpiarForm();
                desacActBotton(true);
            }
        });
        btnLimpiar.setOnAction(e->{
            limpiarForm();
        });
        btnGuardar.setOnAction(e->{
            guardarCliente();
        });
        btnActualizar.setOnAction(e->{
            if (index!=-1){
                guardarCliente();
                desacActBotton(true);
            }
        });
    }

    void desacActBotton(boolean valor){
        btnActualizar.setDisable(valor);
        btnEliminar.setDisable(valor);
    }


    void guardarCliente(){
        String direccion = txtDireccion.getText().trim();
        String nombre = txtNombre.getText().trim();
        String capacidad = cboCapacidad.getValue();
        String estado = cboEstado.getValue();

        boolean faltanDatos = false;
        if (direccion.isEmpty()) {
            faltanDatos = true;
        }
        if (nombre.isEmpty()) {
            faltanDatos = true;
        }
        if (capacidad == null) {
            faltanDatos = true;
        }
        if (estado == null) {
            faltanDatos = true;
        }

        if (faltanDatos) {
            System.out.println(".");
            return;
        }

        Cliente c = new Cliente();
        c.setIdDireccion(direccion);
        c.setNombre(nombre);
        c.setCapacidad(capacidad);
        c.setEstado(estado);

        if (index == -1) {
            cs.save(c);
            limpiarForm();
        } else {
            cs.update(c, index);
            limpiarForm();
            index = -1;
        }
        listar();
    }

    void limpiarForm(){
        txtDireccion.setText("");
        txtNombre.setText("");
        cboCapacidad.setValue(null);
        cboEstado.setValue(null);
        index = -1;
        regClienteTabla.getSelectionModel().clearSelection();
        desacActBotton(true);
        btnGuardar.setDisable(false);
    }

    public void definirColumnas(){
        colDireccion=new TableColumn<>("Direccion");
        colNombre=new TableColumn<>("Nombre");
        colCapacidad=new TableColumn<>("Capacidad");
        colEstado=new TableColumn<>("Estado");
        regClienteTabla.getColumns().addAll(colDireccion, colNombre, colCapacidad, colEstado);
    }

    private void listar(){
        colDireccion.setCellValueFactory(
                cellData->new SimpleStringProperty(cellData.getValue().getIdDireccion()));
        colNombre.setCellValueFactory(
                cellData->new SimpleStringProperty(cellData.getValue().getNombre()));
        colCapacidad.setCellValueFactory(
                cellData->new SimpleStringProperty(cellData.getValue().getCapacidad()));
        colEstado.setCellValueFactory(
                cellData->new SimpleStringProperty(cellData.getValue().getEstado()));
        clientes= FXCollections.observableArrayList(cs.finAll());
        regClienteTabla.setItems(clientes);
    }

    private void agregarEventoSeleccion(){
        regClienteTabla.getSelectionModel().selectedItemProperty()
                .addListener((observable, oldValue, newValue)->{
                   if(newValue!=null){
                       index=regClienteTabla.getItems().indexOf(newValue);
                       txtDireccion.setText(newValue.getIdDireccion());
                       txtNombre.setText(newValue.getNombre());
                       cboCapacidad.setValue(newValue.getCapacidad());
                       cboEstado.setValue(newValue.getEstado());
                       desacActBotton(false);
                       btnGuardar.setDisable(true);
                   }
                });
    }
}
