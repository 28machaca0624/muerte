package pe.edu.upeu.enums;

public enum TipoServicioAgua {
    POTABLE, ALCANTARILLADO, RIEGO, INDUSTRIAL, COMERCIAL, DOMESTICO,
}
