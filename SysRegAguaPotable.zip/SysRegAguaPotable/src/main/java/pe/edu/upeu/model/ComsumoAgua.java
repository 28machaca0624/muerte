package pe.edu.upeu.model;

import lombok.Data;

import java.time.LocalDate;

@Data
public class ComsumoAgua {

    private String idVenta;
    private Cliente cliente;
    private Medidor medidor;
    private double monto;
    private LocalDate fecha;

    public ComsumoAgua(String idVenta, Cliente cliente,
                       Medidor medidor) {
        this.idVenta = idVenta;
        this.cliente = cliente;
        this.medidor = medidor;
        this.monto= medidor.getPrecioBase();
        this.fecha=LocalDate.now();
        medidor.setDisponible(false);
    }
}
