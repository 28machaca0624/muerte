package pe.edu.upeu.model;

import lombok.Data;
import pe.edu.upeu.enums.TipoServicioAgua;

@Data
public class Medidor {
    private String iddireccion;
    private String usuario;
    private String capacidad;
    private int anho;
    private double precioBase;
    private  boolean disponible;
    private TipoServicioAgua tipo;

    public Medidor(String iddireccion, String usuario, String capacidad,
                   int anho, double precioBase, TipoServicioAgua tipo) {
        this.iddireccion = iddireccion;
        this.usuario = usuario;
        this.capacidad = capacidad;
        this.anho = anho;
        this.precioBase = precioBase;
        this.tipo = tipo;
        this.disponible=true;
    }
}
