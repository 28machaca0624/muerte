package pe.edu.upeu.repository;

import pe.edu.upeu.model.Cliente;

import java.util.ArrayList;
import java.util.List;

public class ClienteRepository {
    public static ClienteRepository instace=new ClienteRepository();

    public static ClienteRepository getInstace(){
        if(instace==null){
            instace=new ClienteRepository();
        }
        return instace;
    }


    List<Cliente> clientes=new ArrayList<>();


    public void save(Cliente cliente){
        clientes.add(cliente);
    }
    public List<Cliente> finAll(){
        return clientes;
    }
    public void  update(Cliente c, int index){
        clientes.set(index, c);
    }
    public void delete(int index){
        clientes.remove(index);
    }



    public void cargarDatos(){
        clientes.add(new Cliente("jr.Ñunes 452", "Raul Gomez", "todo el dia", "NORMAL"));
        clientes.add(new Cliente("jr.Tupac amaru 156", "Pedro Apaza", "poca cantidad", "URGENTE"));
        clientes.add(new Cliente("Putina", "Pablo Mamani", "sin agua", "ALERTA"));

    }

}
